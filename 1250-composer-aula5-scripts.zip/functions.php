<?php

function exibeMensagem(string $mensagem)
{
    echo $mensagem . PHP_EOL;
}